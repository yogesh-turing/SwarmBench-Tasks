The supabase repository at /testbed is a large monorepo.

Implement the features slice below so all requirements pass under a limited runtime budget.

## PR-aligned scope

Use these real artifacts as the primary work surface:

- apps/www/app/layout.tsx
- apps/www/app/partners/page.tsx
- apps/www/app/partners/PartnersContent.tsx
- apps/www/app/partners/integrations/page.tsx
- apps/www/app/partners/integrations/IntegrationsContent.tsx
- apps/www/pages/_app.tsx
- apps/www/pages/partners/index.tsx
- apps/www/pages/partners/integrations/index.tsx
- apps/www/components/Partners/BecomeAPartner.tsx
- apps/www/components/Partners/PartnerIntakeForm.tsx
- apps/www/data/partners/index.tsx
- packages/marketing/index.ts
- packages/marketing/src/forms/index.ts
- packages/marketing/src/forms/MarketingForm.tsx
- packages/marketing/src/forms/HubSpotFormEmbed.tsx
- packages/marketing/src/go/schemas.ts
- packages/marketing/src/go/sections/FormSection.tsx
- packages/marketing/src/go/showWhen.ts
- packages/marketing/src/go/actions/submitForm.ts

## Requirements

### Workstream 1: Partners routing and page integration

- Partners pages must be served from the App Router paths for /partners and /partners/integrations.
- "Become a Partner" CTAs must point to #become-a-partner on /partners instead of external forms host URLs.
- Existing partner listing content should remain reachable after routing updates.

### Workstream 2: Partner intake form UX and conditional sections

- Add/render consolidated intake form inline on /partners at #become-a-partner.
- The form must support partner-type driven conditional sections using shared showWhen semantics.
- Include checkbox-group style multi-select support for the Solutions track.

### Workstream 3: Shared marketing form engine behavior

- showWhen evaluation must be centralized in shared marketing logic (no duplicated divergent client/server implementations).
- Schema and section rendering must agree on available field types and conditional behavior.
- Exports/index wiring for marketing form modules must remain consistent.

### Workstream 4: Submission fan-out and provider gating

- Form submission fan-out must support per-provider sendWhen gating.
- All submissions still go to HubSpot.
- Notion mirroring should run only for qualifying partner types (for example Technology Partner), not unconditionally.
- Non-qualifying partner types must not be sent to Notion.

## Cross-artifact consistency requirements

- Routing behavior, CTA links, form rendering, schema rules, and submission fan-out rules must be internally consistent.
- Conditional visibility rules used in the UI must match the same rule semantics used when deciding provider fan-out.
- The implementation should avoid placeholder-only behavior for core gating logic.

## Constraint

- The task is intentionally breadth-heavy under a limited time budget. Prioritize complete, consistent coverage across all workstreams over local one-file optimization.